<?php

class User_model extends CI_Model {
	// method untuk membaca data profile user berdasar username
	public function getUserProfile($username){
		$query = $this->db->get_where('users', array('username' => $username));
		return $query->row_array();
	}
	
	// method untuk menampilkan data user
	public function showUser($id = false){
		// membaca semua data buku dari tabel 'user'
		if ($id == false){
			$query = $this->db->get('users');
			return $query->result_array();
		} else {
			// membaca data user berdasarkan username
			$query = $this->db->get_where('users', array("username" => $id));
			return $query->row_array();
		}
	}

	// method untuk hapus data user berdasarkan id
	public function delUser($id){
		$this->db->delete('users', array("username" => $id));
	}

	// method untuk mencari data user berdasarkan key
	public function findUser($key){

		$query = $this->db->query("SELECT * FROM users WHERE username LIKE '%$key%' 
									OR fullname LIKE '%$key%' 
									OR role LIKE '%$key%'");
		return $query->result_array();
	}

	// method untuk insert data user ke tabel 'users'
	public function insertUser($username, $password, $fullname, $role, $filename){
		$data = array(
					"username" => $username,
					"password" => $password,
					"fullname" => $fullname,
					"role" => $role,
					"imgfile" => $imgfile
		);
		$query = $this->db->insert('users', $data);
	}

	public function pilih($id){ 
		$this->db->where('username',$id);
		return $this->db->get('users')->result();
	}

	public function editUser($username,$password,$fullname,$role){
			
			$this->db->set('password', $password);
			$this->db->set('fullname', $fullname);
			$this->db->set('role', $role);
			$this->db->where('username', $username);
			$this->db->update('users');
		}

	// method untuk membaca data kategori buku dari tabel 'kategori'
	public function getKategori(){
		$query = $this->db->get('kategori');
		return $query->result_array();
	}

	public function getRole(){
		$query = $this->db->get('kategori');
		return $query->result_array();
	}

	// method untuk menghitung jumlah buku berdasarkan idkategori
	public function countByCat($idkategori){
		$query = $this->db->query("SELECT count(*) as jum FROM books WHERE idkategori = '$idkategori'");
		return $query->row()->jum;
	}

}
?>