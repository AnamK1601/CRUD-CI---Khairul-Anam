<?php

class Kategori_model extends CI_Model {

	// method untuk menampilkan kategori
	public function showKategori($id = false){
		// membaca semua kategori dari tabel 'kategori'
		if ($id == false){
			$query = $this->db->get('kategori');
			return $query->result_array();
		} else {
			// membaca kategori berdasarkan id
			$query = $this->db->get_where('kategori', array("idkategori" => $id));
			return $query->row_array();
		}
	}

	// method untuk hapus kategori berdasarkan id
	public function delKategori($id){
		$this->db->delete('kategori', array("idkategori" => $id));
	}

	// method untuk mencari kategori berdasarkan key
	public function findKategori($key){

		$query = $this->db->query("SELECT * FROM kategori WHERE idkategori LIKE '%$key%' 
									OR kategori LIKE '%$key%'");
		return $query->result_array();
	}

	// method untuk insert data buku ke tabel 'kategori'
	public function insertKategori($idkategori, $kategori){
		$data = array(
					"idkategori" => $idkategori,
					"kategori" => $kategori
		);
		$query = $this->db->insert('kategori', $data);
	}

	// method untuk membaca data kategori buku dari tabel 'kategori'
	public function getKategori(){
		$query = $this->db->get('kategori');
		return $query->result_array();
	}

	// method untuk menghitung jumlah buku berdasarkan idkategori
	public function countByCat($idkategori){
		$query = $this->db->query("SELECT count(*) as jum FROM books WHERE idkategori = '$idkategori'");
		return $query->row()->jum;
	}

	public function editKategori($idkategori,$kategori){
			
			$this->db->set('kategori', $kategori);
			$this->db->where('idkategori', $idkategori);
			$this->db->update('kategori');
		}

}
?>