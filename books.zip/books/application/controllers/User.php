<?php
class User extends CI_Controller {

	public function __construct(){
		parent::__construct();
		
		// cek keberadaan session 'username'	
		if (!isset($_SESSION['username'])){
			// jika session 'username' blm ada, maka arahkan ke kontroller 'login'
			redirect('login');
		}
	}


	// method hapus data buku berdasarkan id
	public function delete($id){
		$this->user_model->delUser($id);
		// arahkan ke method 'users' di kontroller 'dashboard'
		redirect('dashboard/users');
	}

	// method untuk tambah data buku
	public function insert(){

		// target direktori fileupload
		$target_dir = "c:/xampp/htdocs/books/assets/images/";
		
		// baca nama file upload
		$filename = $_FILES["imgfile"]["name"];

		// menggabungkan target dir dengan nama file
		$target_file = $target_dir . basename($filename);

		// proses upload
		move_uploaded_file($_FILES["imgfile"]["tmp_name"], $target_file);

		// baca data dari form insert buku
		$username = $_POST['username'];
		$password = $_POST['password'];
		$fullname = $_POST['fullname'];
		$role = $_POST['role'];
		$imgfile = $_POST['imgfile'];

		// panggil method insertBook() di model 'book_model' untuk menjalankan query insert
		$this->user_model->insertUser($username, $password, $fullname, $role, $imgfile);

		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/users');
	}

	public function edit($username){

            $data['countBukuTeks'] = 0;
            $data['countMajalah'] = 0;
            $data['countSkripsi'] = 0;
            $data['countThesis'] = 0;
            $data['countDisertasi'] = 0;
            $data['countNovel'] = 0;

            // baca data session 'fullname' untuk ditampilkan di view
            $data['fullname'] = $_SESSION['fullname'];

            $data['user'] = $this->user_model->showUser($username);

            // tampilkan view 'dashboard/books'
            $this->load->view('dashboard/header', $data);
            $this->load->view('dashboard/edituser');
            $this->load->view('dashboard/footer', $data);
        }

    public function update(){

    		$data['countBukuTeks'] = 0;
            $data['countMajalah'] = 0;
            $data['countSkripsi'] = 0;
            $data['countThesis'] = 0;
            $data['countDisertasi'] = 0;
            $data['countNovel'] = 0;

            // baca data session 'fullname' untuk ditampilkan di view
            $data['fullname'] = $_SESSION['fullname'];

            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $fullname = $this->input->post('fullname');
            $role = $this->input->post('role');
            $this->user_model->editUser($username,$password,$fullname,$role);

            redirect('dashboard/users');
    }

	// method untuk mencari data buku berdasarkan 'key'
	public function findusers(){
		
		// baca key dari form cari data
		$key = $_POST['key'];

		// ambil session fullname untuk ditampilkan ke header
		$data['fullname'] = $_SESSION['fullname'];

		// panggil method findBook() dari model book_model untuk menjalankan query cari data
		$data['users'] = $this->book_model->findUser($key);

		// tampilkan hasil pencarian di view 'dashboard/books'
		$this->load->view('dashboard/header', $data);
        $this->load->view('dashboard/users', $data);
        $this->load->view('dashboard/footer');
	}

}
?>