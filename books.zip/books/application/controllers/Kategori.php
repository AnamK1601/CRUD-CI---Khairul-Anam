<?php
class Kategori extends CI_Controller {

	public function __construct(){
		parent::__construct();
		
		// cek keberadaan session 'username'	
		if (!isset($_SESSION['username'])){
			// jika session 'username' blm ada, maka arahkan ke kontroller 'login'
			redirect('login');
		}
	}


	// method hapus data buku berdasarkan id
	public function delete($id){
		$this->kategori_model->delKategori($id);
		// arahkan ke method 'kategori' di kontroller 'dashboard'
		redirect('dashboard/kategori');
	}

	// method untuk tambah data kategori
	public function insert(){

		// baca data dari form insert kategori
		$idkategori = $_POST['idkategori'];
		$kategori = $_POST['kategori'];

		// panggil method insertKategori() di model 'kategori_model' untuk menjalankan query insert
		$this->kategori_model->insertKategori($idkategori, $kategori);

		// arahkan ke method 'kategori' di kontroller 'dashboard'
		redirect('dashboard/kategori');
	}

	// method untuk edit data buku berdasarkan id
	public function edit($id){

	}

	// method untuk update data buku berdasarkan id
	public function update(){
		$data['countBukuTeks'] = 0;
		$data['countMajalah'] = 0;
		$data['countSkripsi'] = 0;
		$data['countThesis'] = 0;
		$data['countDisertasi'] = 0;
		$data['countNovel'] = 0;

            // baca data session 'fullname' untuk ditampilkan di view
		$data['fullname'] = $_SESSION['fullname'];

		$idkategori = $this->input->post('idkategori');
		$kategori = $this->input->post('kategori');
		$this->kategori_model->editKategori($idkategori,$kategori);

		redirect('dashboard/kategori');
	}

	// method untuk mencari data buku berdasarkan 'key'
	public function findkategori(){
		
		// baca key dari form cari data
		$key = $_POST['key'];

		// ambil session fullname untuk ditampilkan ke header
		$data['fullname'] = $_SESSION['fullname'];

		// panggil method findBook() dari model kategori_model untuk menjalankan query cari data
		$data['kategori'] = $this->kategori_model->findKategori($key);

		// tampilkan hasil pencarian di view 'dashboard/books'
		$this->load->view('dashboard/header', $data);
        $this->load->view('dashboard/books', $data);
        $this->load->view('dashboard/footer');
	}

}
?>