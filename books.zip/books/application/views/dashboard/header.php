<!DOCTYPE html>
<!-- saved from url=(0053)https://getbootstrap.com/docs/4.3/examples/dashboard/ -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.5">
    <title>Dashboard Template · Bootstrap</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/dashboard/">

    <!-- Bootstrap core CSS -->
    <!-- arahkan url ke direktori 'assets' -->
<link href="<?php echo base_url();?>assets/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <!-- Custom styles for this template -->
    <!-- arahkan url ke direktori 'assets' -->
    <link href="<?php echo base_url();?>assets/dashboard.css" rel="stylesheet">
  <style type="text/css">/* Chart.js */
@-webkit-keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}@keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}.chartjs-render-monitor{-webkit-animation:chartjs-render-animation 0.001s;animation:chartjs-render-animation 0.001s;}</style></head>
  <body>
    <nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
  <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="https://getbootstrap.com/docs/4.3/examples/dashboard/#">Books Project</a>

  <!-- tampilkan fullname dari user yang sedang login -->
  <div class="w-100" style="margin-left: 25px; color: white;">Welcome, <?php echo $fullname; ?></div>

  <ul class="navbar-nav px-3">
    <li class="nav-item text-nowrap">
      <!-- arahkan link ke kontroller 'dashboard/logout' -->
      <a class="nav-link" href="<?php echo site_url('dashboard/logout');?>">Sign out</a>
    </li>
  </ul>
</nav>

<div class="container-fluid">
  <div class="row">
    <nav class="col-md-2 d-none d-md-block bg-light sidebar">
      <div class="sidebar-sticky">
        <ul class="nav flex-column">
          <li class="nav-item">
            <!-- arahkan link ke kontroller 'dashboard/index' -->
            <a class="nav-link" href="<?php echo site_url('dashboard'); ?>">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home"><path fill="#000000" d="M10,20V14H14V20H19V12H22L12,3L2,12H5V20H10Z"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
              Dashboard
            </a>
          </li>
          <?php if($_SESSION['role'] == 'admin'): ?>
            <li class="nav-item">
            <!-- arahkan link ke kontroller 'dashboard/add' -->
            <a class="nav-link" href="<?php echo site_url('dashboard/add'); ?>">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path fill="#000000" d="M19,11H15V15H13V11H9V9H13V5H15V9H19M20,2H8A2,2 0 0,0 6,4V16A2,2 0 0,0 8,18H20A2,2 0 0,0 22,16V4A2,2 0 0,0 20,2M4,6H2V20A2,2 0 0,0 4,22H18V20H4V6Z"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
              Tambah Data Buku
            </a>
          </li>
          <?php endif; ?>
          <li class="nav-item">
            <!-- arahkan link ke kontroller 'dashboard/books' -->
            <a class="nav-link" href="<?php echo site_url('dashboard/books'); ?>">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-cart"><path fill="#000000" d="M19,7H9V5H19M15,15H9V13H15M19,11H9V9H19M20,2H8A2,2 0 0,0 6,4V16A2,2 0 0,0 8,18H20A2,2 0 0,0 22,16V4A2,2 0 0,0 20,2M4,6H2V20A2,2 0 0,0 4,22H18V20H4V6Z"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
              Data Buku
            </a>
          </li>
          <?php if($_SESSION['role'] == 'admin'): ?>
          <li class="nav-item">
            <!-- arahkan link ke kontroller 'dashboard/books' -->
            <a class="nav-link" href="<?php echo site_url('dashboard/kategori'); ?>">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-cart"> <path fill="#000000" d="M3,4H7V8H3V4M9,5V7H21V5H9M3,10H7V14H3V10M9,11V13H21V11H9M3,16H7V20H3V16M9,17V19H21V17H9"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle></path></svg>
              Kategori


            </a>
          </li>
          <li class="nav-item">
            <!-- arahkan link ke kontroller 'dashboard/books' -->
            <!-- /user/tambah, /dashboar/tambah_user -->
            <a class="nav-link" href="<?php echo site_url('dashboard/users'); ?>"> 
              <svg style="width:24px;height:24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-cart">
              <path fill="#000000" d="M9,13.75C6.66,13.75 2,14.92 2,17.25V19H16V17.25C16,14.92 11.34,13.75 9,13.75M4.34,17C5.18,16.42 7.21,15.75 9,15.75C10.79,15.75 12.82,16.42 13.66,17M9,12A3.5,3.5 0 0,0 12.5,8.5A3.5,3.5 0 0,0 9,5A3.5,3.5 0 0,0 5.5,8.5A3.5,3.5 0 0,0 9,12M9,7A1.5,1.5 0 0,1 10.5,8.5A1.5,1.5 0 0,1 9,10A1.5,1.5 0 0,1 7.5,8.5A1.5,1.5 0 0,1 9,7M16.04,13.81C17.2,14.65 18,15.77 18,17.25V19H22V17.25C22,15.23 18.5,14.08 16.04,13.81M15,12A3.5,3.5 0 0,0 18.5,8.5A3.5,3.5 0 0,0 15,5C14.46,5 13.96,5.13 13.5,5.35C14.13,6.24 14.5,7.33 14.5,8.5C14.5,9.67 14.13,10.76 13.5,11.65C13.96,11.87 14.46,12 15,12Z"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
              Users
            </a>
          </li>
          <?php endif; ?>
        </ul>

      </div>
    </nav>