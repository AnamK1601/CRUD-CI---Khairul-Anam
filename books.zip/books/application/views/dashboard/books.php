
    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">

    <form method="post" action="<?php echo site_url('book/findbooks'); // arahkan form submit ke kontroller 'book/findbooks ?>">
    <input class="form-control form-control-dark" type="text" placeholder="Search" aria-label="Search" name="key" style="border: 1px solid #cccccc; margin-top: 20px;">
    </form>

      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Daftar Buku</h1>
      </div>

      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>Judul Buku</th>
              <th>Pengarang</th>
              <th>Penerbit</th>
              <th>Tahun Terbit</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            // menampilkan data buku
            foreach ($book as $book_item): 

            ?>
            <tr>
              <td><?php echo $book_item['judul']?></td>
              <td><?php echo $book_item['pengarang']?></td>
              <td><?php echo $book_item['penerbit']?></td>
              <td><?php echo $book_item['thnterbit']?></td>
              <td>
                <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="modal" data-target="#ModalView<?php echo $book_item['idbuku']?>">View</button> 
                | <button type="button" class="btn btn-sm btn-outline-secondary"><?php echo anchor('book/edit/'.$book_item['idbuku'], 'Edit'); ?></button>
                | <button type="button" class="btn btn-sm btn-outline-secondary"><?php echo anchor('book/delete/'.$book_item['idbuku'], 'Del'); ?>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
          <tfoot>
            <th><?php echo "Total Buku : ".$totalBuku; ?></th>
          </tfoot>
        </table>
        <?php 
        echo $this->pagination->create_links();
        ?>
      </div>

      <!-- Modal View -->
      <?php 
            // menampilkan data kategori
      foreach ($book as $book_item): 

        ?>
        <div id="ModalView<?php echo $book_item['idbuku']?>" class="modal fade" role="dialog">
          <div class="modal-dialog">
            <!-- konten modal-->
            <div class="modal-content">
              <!-- heading modal -->
              <div class="modal-header">
                <h2>View Data Kategori</h2>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
              <!-- body modal -->
              <div class="modal-body">
                <div class="form-group row">
                  <label for="judul" class="col-sm-2 col-form-label">Judul</label>
                  <div class="col-sm-10">
                    <?php echo $book_item['judul']?>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="pengarang" class="col-sm-2 col-form-label">Pengarang</label>
                  <div class="col-sm-10">
                    <?php echo $book_item['pengarang']?>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="penerbit" class="col-sm-2 col-form-label">Penerbit</label>
                  <div class="col-sm-10">
                    <?php echo $book_item['penerbit']?>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="thnterbit" class="col-sm-2 col-form-label">thnterbit</label>
                  <div class="col-sm-10">
                    <?php echo $book_item['thnterbit']?>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="filename" class="col-sm-2 col-form-label">Image Cover</label>
                  <div class="col-sm-10">
                    <img src="<?php echo base_url(); ?>assets/image/filename.jpg">
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
      <!-- End of Modal -->
    </main>
  