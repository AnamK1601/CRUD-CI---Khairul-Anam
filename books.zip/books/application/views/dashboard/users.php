<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="assets/bootstrap.css">
  <script type="text/javascript" src="assets/jquery.js"></script>
  <script type="text/javascript" src="assets/bootstrap.js"></script>
</head>
<body>
  <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">

    <form method="post" action="<?php echo site_url('user/findusers'); // arahkan form submit ke kontroller 'book/findbooks ?>">
      <input class="form-control form-control-dark" type="text" placeholder="Search" aria-label="Search" name="key" style="border: 1px solid #cccccc; margin-top: 20px;">
    </form>

    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
      <table>
        <tr>
          <td><h1 class="h2">Daftar User</h1></td>
          <td></td>
        </tr>
      </table>
    </div>

    <div class="table-responsive">
      <table class="table table-striped table-sm">
        <thead>
          <tr>
            <th>Username</th>
            <th>Password</th>
            <th>Fullname</th>
            <th>Role</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php 
            // menampilkan data user
          foreach ($user as $user_item): 

            ?>
            <tr>
              <td><?php echo $user_item['username']?></td>
              <td><?php echo $user_item['password']?></td>
              <td><?php echo $user_item['fullname']?></td>
              <td><?php echo $user_item['role']?></td>
              <td><button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="modal" data-target="#ModalView<?php echo $user_item['username']?>">View</button> 
                | <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="modal" data-target="#ModalEdit<?php echo $user_item['username']?>">Edit</button> 
                | <button type="button" class="btn btn-sm btn-outline-secondary"><?php echo anchor('user/delete/'.$user_item['username'], 'Del'); ?></button></td>
              </tr>
            <?php endforeach; ?>
            <button type="button" class="btn btn-primary mb-2" data-toggle="modal" data-target="#ModalAdduser">Add User</button>
          </tbody>
        </table>
      
        <!-- Modal View -->
        <?php 
            // menampilkan data user
        foreach ($user as $user_item): 

          ?>
          <div id="ModalView<?php echo $user_item['username']?>" class="modal fade" role="dialog">
            <div class="modal-dialog">
              <!-- konten modal-->
              <div class="modal-content">
                <!-- heading modal -->
                <div class="modal-header">
                  <h2>View Data User</h2>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- body modal -->
                <form>
                  <div class="modal-body">
                    <div class="form-group row">
                      <label for="username" class="col-sm-2 col-form-label">Username</label>
                      <div class="col-sm-10">
                        <?php echo $user_item['username']?>
                      </div>
                    </div>

                    <div class="form-group row">
                      <label for="password" class="col-sm-2 col-form-label">Password</label>
                      <div class="col-sm-10">
                        <?php echo $user_item['password']?>
                      </div>
                    </div>

                    <div class="form-group row">
                      <label for="fullname" class="col-sm-2 col-form-label">Fullname</label>
                      <div class="col-sm-10">
                        <?php echo $user_item['fullname']?>
                      </div>
                    </div>

                    <div class="form-group row">
                      <label for="role" class="col-sm-2 col-form-label">Role</label>
                      <div class="col-sm-10">
                        <?php echo $user_item['role']?>
                      </div>
                    </div>

                    <div class="form-group row">
                      <label for="imgfile" class="col-sm-2 col-form-label"></label>
                      <div class="col-sm-10">
                        <?php echo $user_item['imgfile']?>
                      </div>
                    </div>

                  </div>
                </form>
                
              </div>
            </div>
          </div>
        <?php endforeach; ?>
        <!-- End of Modal -->

        <!-- Modal Adduser -->
        <?php 
            // menambah data user
        foreach ($user as $user_item): 

          ?>
          <div id="ModalAdduser" class="modal fade" role="dialog">
            <div class="modal-dialog">
              <!-- konten modal-->
              <div class="modal-content">
                <!-- heading modal -->
                <div class="modal-header">
                  <h2>Add User</h2>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- body modal -->
                <div class="modal-body">
                   <?php
            // arahkan form submit ke kontroller 'user/insert' 
                    echo form_open_multipart('user/insert'); 
                    ?>
                  <form class="form-horizontal" method="post" action="<?php echo base_url().'index.php/dashboard/users'?>">


                    <div class="form-group row">
                      <label for="username" class="col-sm-2 col-form-label">Username</label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" name="username" placeholder="Masukkan username">
                      </div>
                    </div>

                    <div class="form-group row">
                      <label for="password" class="col-sm-2 col-form-label">Password</label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" name="password" placeholder="Masukkan password">
                      </div>
                    </div>

                    <div class="form-group row">
                      <label for="fullname" class="col-sm-2 col-form-label">Fullname</label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" name="fullname" placeholder="Masukkan fullname">
                      </div>
                    </div>

                    <div class="form-group row">
                      <label for="role" class="col-sm-2 col-form-label">Role</label>
                      <div class="col-sm-10">
                        
                          <select class="form-control">
                            <?php 
                        // menamba data user
                        foreach ($user as $user_item): 
                          ?>
                            <option class="form-control" name="role" value="<?php echo $user_item['role']?>"><?php echo $user_item['role']?></option>
                            <?php endforeach; ?>
                          </select>
                         
                      </div>
                    </div>

                    <div class="form-group row">
                      <label for="imgfile" class="col-sm-2 col-form-label">Image Profil</label>
                      <div class="col-sm-10">
                        <input type="file" class="form-control-file" name="imgfile">
                      </div>
                    </div>

                    <div class="form-group row">
                      <div class="col-sm-2">
                      </div>
                      <div class="col-sm-10">
                        <button type="submit" name="insert" class="btn btn-primary mb-2">Submit Data User</button>        
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
        <!-- End of Modal -->

        <!-- Modal Edit -->
        <?php 
            // mengubah data user
        foreach ($user as $user_item): 

          ?>
          <div id="ModalEdit<?php echo $user_item['username']?>" class="modal fade" role="dialog">
            <div class="modal-dialog">
              <!-- konten modal-->
              <div class="modal-content">
                <!-- heading modal -->
                <div class="modal-header">
                  <h2>Edit Data Kategori</h2>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                
                  <!-- body modal -->
                  <div class="modal-body">
                    <?php
            // arahkan form submit ke kontroller 'user/update' 
                    echo form_open_multipart('user/update'); 
                    ?>
                    <form class="form-horizontal" method="post">
                      <div class="form-group row">
                        <label for="username" class="col-sm-2 col-form-label">Username</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="username" value="<?php echo $user_item['username']?>">
                        </div>
                      </div>

                      <div class="form-group row">
                        <label for="password" class="col-sm-2 col-form-label">Password</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="password" value="<?php echo $user_item['password']?>">
                        </div>
                      </div>

                      <div class="form-group row">
                        <label for="fullname" class="col-sm-2 col-form-label">Fullname</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="fullname" value="<?php echo $user_item['fullname']?>">
                        </div>
                      </div>

                      <div class="form-group row">
                        <label for="role" class="col-sm-2 col-form-label">Role</label>
                        <div class="col-sm-10">
                          <select class="form-control">
                            <?php 
            // mengubah data user
                            foreach ($user as $user_item): 

                              ?>
                              <option class="form-control" name="role" value="<?php echo $user_item['role']?>"><?php echo $user_item['role']?></option>
                              <?php endforeach; ?>
                          </select>
                        </div>
                      </div>

                      <div class="form-group row">
                        <div class="col-sm-2">
                        </div>
                        <div class="col-sm-10">
                          <button type="submit" name="edit" class="btn btn-primary mb-2">Edit</button>        
                        </div>
                      </div>
                    </form>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
        <!-- End of Modal -->
      </div>
    </main>
  </body>
  </html>

  